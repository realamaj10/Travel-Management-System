package view;

import javafx.stage.Stage;
import model.base.Client;

public class PersonalizedView {

    private Client personalized;

    public PersonalizedView(Client personalized) {
        this.personalized = personalized;
    }

    public PersonalizedView() {
        super();
    }
    public void show(Stage st) {
        
        //MAP

//        Button go = new Button("Go to create a bill");
//        Button back = new Button("Return");
//
//        VBox v1 = new VBox();
//        v1.getChildren().addAll(go, back);
//        v1.setSpacing(7);
//        v1.setAlignment(Pos.CENTER);
//
//        Scene sc = new Scene(v1, 700, 700);
//        st.setScene(sc);
//        st.setTitle("Pharmacist View");
//        st.show();
////
////        button functions
//
//        go.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent arg0) {
//                (new BillView()).show(st);
//                st.show();
//            }
//        });
//
//        back.setOnAction(new EventHandler<ActionEvent>(){
//			@Override
//			public void handle(ActionEvent arg0) {
//				(new Login()).show(st);
//				st.show();
//			}
//		});
    }
}
